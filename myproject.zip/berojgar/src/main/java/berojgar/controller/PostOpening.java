package berojgar.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import berojgar.dao.OpeningsDao;
import berojgar.dto.Company;
import berojgar.dto.Opening;
import berojgar.dto.Degree;


@WebServlet("/PostOpening")
public class PostOpening extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		HttpSession httpSession = req.getSession();
		Company company=(Company)httpSession.getAttribute("user");
		
		String position=req.getParameter("position");
		String skills=req.getParameter("skills");
		
		
		
		String[] givenDegrees=req.getParameter("degree").split(",");
		
		List<Degree> degrees=new ArrayList<Degree>();
		
		for(String d:givenDegrees)
		{
			Degree degree=new Degree();
			degree.setName(d);
			
			degrees.add(degree);
		}
				
		double experience=Double.parseDouble(req.getParameter("experience"));
		int numberOfOpenings=Integer.parseInt(req.getParameter("numberOfOpenings"));
		
		Opening opening=new Opening();
		opening.setCompany(company);
		opening.setPosition(position);
		opening.setSkills(skills);
		opening.setDegree(degrees);
		opening.setExperience(experience);
		opening.setNumberOfOpenings(numberOfOpenings);
		
		OpeningsDao openingsDao=new OpeningsDao();
		Opening result= openingsDao.saveOpening(opening);
		if(result!=null)
		{
			 PrintWriter printWriter = resp.getWriter();
			printWriter.write("<div align='center'><h1 style=color:green> Opening posted  ! </h1></div>");

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("CompanyHome.jsp");
			try {
				requestDispatcher.forward(req, resp);
			} catch (ServletException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		} else {
			PrintWriter printWriter = null;
			try {
				printWriter = resp.getWriter();
			} catch (IOException e) {

				e.printStackTrace();
			}
			printWriter.write("<div align='center'><h1 style=color:red>Unable to create job post ! </h1></div>");

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("CompanyHome.jsp");
			try {
				requestDispatcher.include(req, resp);
			} catch (ServletException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
			
		}
		
	}

}
