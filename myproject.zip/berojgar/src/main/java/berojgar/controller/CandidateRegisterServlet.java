package berojgar.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.print.DocFlavor.INPUT_STREAM;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import berojgar.dao.CandidateDao;

import berojgar.dto.Candidate;
@ MultipartConfig
@WebServlet("/CandidateRegisterServlet")
public class CandidateRegisterServlet extends HttpServlet {

	CandidateDao candidateDao = new CandidateDao();

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String name = req.getParameter("name");
		String email = req.getParameter("email");
		long phone = Long.parseLong(req.getParameter("phone"));
		
		String education = req.getParameter("education");
		String university = req.getParameter("university");
		int yop = Integer.parseInt(req.getParameter("yop"));
		String address = req.getParameter("address");
		String password = req.getParameter("password");
		
		Candidate candidate = new Candidate();
		candidate.setName(name);
		candidate.setEmail(email);
		candidate.setPhone(phone);
		
		candidate.setEducation(education);
		candidate.setUniversity(university);
		candidate.setYop(yop);
		candidate.setAddress(address);
		candidate.setPassword(password);		

		if (candidateDao.saveCandidate(candidate) == 1) {			
						
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("CandidateLogin.html");
			requestDispatcher.forward(req, resp);
			

		} else {	
			
			PrintWriter printWriter = resp.getWriter();
			printWriter.write("<div align='center'><h1 style=color:red> Invalid credentials ! </h1></div>");
		    
			
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("candidateRegistration.html");
			requestDispatcher.include(req, resp);

		}

	}

}
