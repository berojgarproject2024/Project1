package berojgar.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import berojgar.dao.CompanyDao;
import berojgar.dto.Company;

@WebServlet("/CompanyRegisterServlet")
public class CompanyRegisterServlet extends HttpServlet {
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		String gst=req.getParameter("gst");
		
		int numberOfEmployees=Integer.parseInt(req.getParameter("numberOfEmployees"));
		String industry=req.getParameter("industry");
		String specialties=req.getParameter("specialties");
		
		String headquarters=req.getParameter("headquarters");	
		String password=req.getParameter("password");
		
		Company company=new Company();
		company.setName(name);
		company.setEmail(email);
		company.setGst(gst);
		
		company.setNumberOfEmployees(numberOfEmployees);
		company.setIndustry(industry);
		company.setSpecialties(specialties);
		
		company.setHeadquarters(headquarters);
		company.setPassword(password);
		
		
		CompanyDao companyDao= new CompanyDao();
		if(companyDao.saveCompany(company)==1)
		{
			RequestDispatcher requestDispatcher= req.getRequestDispatcher("CompanyLogin.html");
			requestDispatcher.forward(req, resp);
			
		}
		else
		{
			PrintWriter printWriter= resp.getWriter();
			printWriter.write("<div align='center'><h1 style=color:red> Invalid credentials ! </h1></div>");
			RequestDispatcher requestDispatcher=req.getRequestDispatcher("CompanyRegistration.html");
			requestDispatcher.include(req, resp);
			
		}
		
		
	}

}
