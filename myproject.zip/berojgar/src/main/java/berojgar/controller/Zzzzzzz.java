package berojgar.controller;

import berojgar.dao.CandidateDao;

public class Zzzzzzz {
	
	public static void main(String[] args) {
		
		CandidateDao candidateDao=new CandidateDao();
		System.out.println(candidateDao.getAllCandidate());;
	}

}
