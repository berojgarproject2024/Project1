package berojgar.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import berojgar.dao.CompanyDao;
import berojgar.dto.Company;

@WebServlet("/CompanyLoginServlet")
public class CompanyLoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession session = req.getSession();
		session.invalidate();

		String email = req.getParameter("email");
		String password = req.getParameter("password");

		CompanyDao companyDao = new CompanyDao();
		Company company = companyDao.getCompanyAndValidate(email, password);

		if (company != null) {
			HttpSession httpSession = req.getSession();
			httpSession.setAttribute("user", company);

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("CompanyHome.jsp");
			try {
				requestDispatcher.forward(req, resp);
			} catch (ServletException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		} else {
			PrintWriter printWriter = null;
			try {
				printWriter = resp.getWriter();
			} catch (IOException e) {

				e.printStackTrace();
			}
			printWriter.write("<div align='center'><h1 style=color:red> Invalid credentials ! </h1></div>");

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("CompanyLogin.html");
			try {
				requestDispatcher.include(req, resp);
			} catch (ServletException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

}
