package berojgar.controller;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import berojgar.dao.CandidateDao;
import berojgar.dto.Candidate;

@WebServlet("/CandidateLoginServlet")
public class CandidateLoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) {
		HttpSession session = req.getSession();
		session.invalidate();
		
		String email = req.getParameter("email");
		String password = req.getParameter("password");

		CandidateDao candidateDao = new CandidateDao();
		Candidate candidate = candidateDao.getCandidateAndValidate(email, password);

		if (candidate != null) {
			HttpSession httpSession = req.getSession();
			httpSession.setAttribute("user",candidate);
			

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("CandidateHome.jsp");
			try {
				requestDispatcher.forward(req, resp);
			} catch (ServletException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		} else {
			PrintWriter printWriter = null;
			try {
				printWriter = resp.getWriter();
			} catch (IOException e) {

				e.printStackTrace();
			}
			printWriter.write("<div align='center'><h1 style=color:red> Invalid credentials ! </h1></div>");

			RequestDispatcher requestDispatcher = req.getRequestDispatcher("CandidateLogin.html");
			try {
				requestDispatcher.include(req, resp);
			} catch (ServletException e) {

				e.printStackTrace();
			} catch (IOException e) {

				e.printStackTrace();
			}
		}
	}

}
