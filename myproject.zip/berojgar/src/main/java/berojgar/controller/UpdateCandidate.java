package berojgar.controller;

import java.io.IOException;
import java.io.InputStream;

import javax.print.DocFlavor.INPUT_STREAM;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import berojgar.dao.ImageDao;
import berojgar.dto.Candidate;

@MultipartConfig
@WebServlet("/updateCandidate")
public class UpdateCandidate extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Part image = req.getPart("image");

		InputStream stream = image.getInputStream();
		byte[] bs = new byte[stream.available()];
		stream.read(bs);

		String fName = req.getParameter("first_name");
		String lName = req.getParameter("last_name");
		String email = req.getParameter("email");
		long phone = Long.parseLong(req.getParameter("phone"));
		String education = req.getParameter("education");
		String password = req.getParameter("password");

		ImageDao dao = new ImageDao();
		Candidate candidate = new Candidate();
		candidate.setC_Id(((Candidate) req.getSession().getAttribute("user")).getC_Id());
		candidate.setProfileImage(bs);
		
		candidate.setFirst_name(fName);
		candidate.setLast_name(lName);
		candidate.setEmail(email);
		candidate.setPhone(phone);
		candidate.setEducation(education);
		candidate.setPassword(password);
		
		Candidate candidate2 = dao.saveImage(candidate);
		if(candidate2!=null)
		{
			req.getSession().setAttribute("user", candidate2);
		}

	}

}
