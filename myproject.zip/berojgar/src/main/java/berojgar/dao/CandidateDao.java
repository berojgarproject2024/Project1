package berojgar.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import berojgar.dto.Candidate;

public class CandidateDao {

	public EntityManager getEntityManager() {

		return Persistence.createEntityManagerFactory("berojgar").createEntityManager();

	}

	public int saveCandidate(Candidate candidate) {

		EntityManager entityManager = getEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		
		try {			
			entityTransaction.begin();
			entityManager.persist(candidate);
			entityTransaction.commit();
		} catch (Exception e) {

			return -1;

		}

		return 1;

	}

	public Candidate getCandidateAndValidate(String email, String password) {

		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select c from Candidate c where c.email=?1 and c.password=?2");
		query.setParameter(1, email);
		query.setParameter(2, password);

		try {
			Candidate candidate = (Candidate) query.getSingleResult();
			

			return candidate;

		} catch (NoResultException n) {
			return null;
		}
	}

	public Candidate getCandidate(int c_id) {

		EntityManager entityManager = getEntityManager();
		return entityManager.find(Candidate.class, c_id);

	}

	public List<Candidate> getAllCandidate() {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select c from Candidate c");

		try {
			List<Candidate> candidates = (List<Candidate>) query.getResultList();

			return candidates;

		} catch (NoResultException n) {
			return null;
		}

	}

}
