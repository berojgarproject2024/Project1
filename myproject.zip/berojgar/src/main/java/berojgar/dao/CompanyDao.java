package berojgar.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import berojgar.dto.Candidate;
import berojgar.dto.Company;

public class CompanyDao {

	public EntityManager getEntityManager() {
		return Persistence.createEntityManagerFactory("berojgar").createEntityManager();
	}

	public int saveCompany(Company company) {

		EntityManager entityManager = getEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		try {
			entityTransaction.begin();
			entityManager.persist(company);
			entityTransaction.commit();

		} catch (Exception e) {
			return -1;
		}
		return 1;
	}

	public Company getCompanyAndValidate(String email, String password) {

		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select c from Company c where c.email=?1 and c.password=?2");
		query.setParameter(1, email);
		query.setParameter(2, password);

		try {
			Company company = (Company) query.getSingleResult();

			return company;

		} catch (NoResultException n) {
			return null;
		}
	}

	public List<Company> getAllCompanyWhoseOpeningIsOpen() {
		EntityManager entityManager = getEntityManager();
		Query query = entityManager.createQuery("select c from Company c where c.isOpening=true");

		try {
			List<Company> companies = (List<Company>) query.getResultList();

			return companies;

		} catch (NoResultException n) {
			return null;
		}

	}
	public List<Candidate> getAllCandidateWhoAppliedForOpenings(int c_id) {
		EntityManager entityManager= getEntityManager();
		Query query= entityManager.createQuery("select cc from company_candidate cc where cc.c_id=?1");
		query.setParameter(1, c_id);
		try {
			
			List<Candidate> candidates= query.getResultList();
			System.out.println(candidates);
			return candidates;
		}
		catch (Exception e) {
			return null;
		}
		
		
		
	}

}
