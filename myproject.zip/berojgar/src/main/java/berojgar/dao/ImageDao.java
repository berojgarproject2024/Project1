package berojgar.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;


import berojgar.dto.Candidate;

public class ImageDao {

	public EntityManager getEntityManager() {

		return Persistence.createEntityManagerFactory("berojgar").createEntityManager();

	}

	public Candidate saveImage(Candidate candidate) {
		EntityManager entityManager = getEntityManager();
		EntityTransaction entityTransaction = entityManager.getTransaction();

		try {
			entityTransaction.begin();

			entityManager.merge(candidate);
			entityTransaction.commit();

		} catch (NoResultException n) {
			return null;
		}
		return candidate;
		

		

	}

}
