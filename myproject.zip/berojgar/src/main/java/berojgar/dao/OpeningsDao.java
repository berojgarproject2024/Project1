package berojgar.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.NoResultException;
import javax.persistence.Persistence;
import javax.persistence.Query;

import berojgar.dto.Candidate;
import berojgar.dto.Opening;

public class OpeningsDao {

	public EntityManager getEntityManager() {

		return Persistence.createEntityManagerFactory("berojgar").createEntityManager();

	}

	public Opening saveOpening(Opening opening) {

		EntityManager entityManager = getEntityManager();

		EntityTransaction entityTransaction = entityManager.getTransaction();

		try {
			entityTransaction.begin();
			entityManager.persist(opening);
			entityTransaction.commit();
		} catch (Exception e) {

			e.printStackTrace();

		}

		return opening;

	}
	public List<Opening> getAllOpening() {

		EntityManager entityManager = getEntityManager();
		
		Query query = entityManager.createQuery("select o from Opening o");

		try {
			List<Opening> openings = ((List<Opening>) query.getResultList());

			return openings;

		} catch (NoResultException n) {
			return null;
		}

	}
	public List<Opening> getAllOpeningOfComapny(int id) {

		EntityManager entityManager = getEntityManager();
		
		Query query = entityManager.createQuery("select o from Opening o where o.id=?1");
		query.setParameter(1, id);

		try {
			List<Opening> openings = ((List<Opening>) query.getResultList());

			return openings;

		} catch (NoResultException n) {
			return null;
		}

	}

}
