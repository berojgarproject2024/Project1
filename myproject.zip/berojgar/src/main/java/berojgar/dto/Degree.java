package berojgar.dto;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;


@Entity
public class Degree {
	
	@Id	
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;	
	private String name ;
	
	
	@ManyToOne
	@JoinColumn	
	private Opening opening;


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Opening getOpening() {
		return opening;
	}


	public void setOpening(Opening opening) {
		this.opening = opening;
	}


	@Override
	public String toString() {
		return "Qualification [id=" + id + ", name=" + name + ", opening=" + opening + "]";
	}

	
	
	

	

	
	
}
