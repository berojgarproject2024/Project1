package berojgar.dto;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;

@Entity
public class Company {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)	
	private int com_Id;
	private String name;
	@Column(unique = true)
	private String email;
	
	@Column(unique = true)
	private String gst;	
	private int numberOfEmployees;
	private String industry;
	
	private String specialties;	
	private String headquarters;		
	private String password;
	
	private boolean isOpening=false;

	@ManyToMany
	@JoinTable(joinColumns = @JoinColumn(name = "com_Id"), inverseJoinColumns = @JoinColumn(name = "c_Id"))
	private List<Candidate> Candidates;

	@OneToMany(cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	private List<Opening> Openings;

	public int getCom_Id() {
		return com_Id;
	}

	public void setCom_Id(int com_Id) {
		this.com_Id = com_Id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getGst() {
		return gst;
	}

	public void setGst(String gst) {
		this.gst = gst;
	}

	public int getNumberOfEmployees() {
		return numberOfEmployees;
	}

	public void setNumberOfEmployees(int numberOfEmployees) {
		this.numberOfEmployees = numberOfEmployees;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getSpecialties() {
		return specialties;
	}

	public void setSpecialties(String specialties) {
		this.specialties = specialties;
	}

	public String getHeadquarters() {
		return headquarters;
	}

	public void setHeadquarters(String headquarters) {
		this.headquarters = headquarters;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public boolean isOpening() {
		return isOpening;
	}

	public void setOpening(boolean isOpening) {
		this.isOpening = isOpening;
	}

	public List<Candidate> getCandidates() {
		return Candidates;
	}

	public void setCandidates(List<Candidate> candidates) {
		Candidates = candidates;
	}

	public List<Opening> getOpenings() {
		return Openings;
	}

	public void setOpenings(List<Opening> openings) {
		Openings = openings;
	}

	@Override
	public String toString() {
		return "Company [com_Id=" + com_Id + ", name=" + name + ", email=" + email + ", gst=" + gst
				+ ", numberOfEmployees=" + numberOfEmployees + ", industry=" + industry + ", specialties=" + specialties
				+ ", headquarters=" + headquarters + ", password=" + password + ", isOpening=" + isOpening
				+ ", Candidates=" + Candidates + ", Openings=" + Openings + "]";
	}

	

	
	

}
